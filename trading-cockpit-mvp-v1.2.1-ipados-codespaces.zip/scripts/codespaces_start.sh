#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

if [ ! -f .env ]; then
  cp .env.example .env
fi

echo "Starting Trading Cockpit with Docker Compose..."
docker compose up -d --build

echo ""
echo "Services are starting. In GitHub Codespaces, open the Ports tab:"
echo "- Port 3000: Frontend"
echo "- Port 8000: API; add /docs for Swagger"
echo ""
echo "Useful checks:"
echo "  bash scripts/codespaces_status.sh"
echo "  curl http://localhost:8000/health"
echo "  curl http://localhost:8000/api/ops/readiness"
