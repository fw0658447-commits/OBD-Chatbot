#!/usr/bin/env bash
set -euo pipefail

echo "Health:"
curl -s http://localhost:8000/health

echo "\nReadiness:"
curl -s http://localhost:8000/api/ops/readiness

echo "\nBot config:"
curl -s http://localhost:8000/api/bot/config

echo "\nRun one paper bot cycle:"
curl -s -X POST http://localhost:8000/api/bot/run-cycle \
  -H 'Content-Type: application/json' \
  -d '{"symbol":"BTC/USD","timeframe":"1h","strategy_name":"trend_atr_v0.7","decision_mode":"rule"}'

echo "\nOrders:"
curl -s http://localhost:8000/api/bot/orders

echo ""
