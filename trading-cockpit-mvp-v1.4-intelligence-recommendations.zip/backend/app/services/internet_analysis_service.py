from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import requests

from app.config import settings


class InternetAnalysisService:
    """Fetch lightweight online context for a symbol.

    This service is intentionally conservative: if API keys are missing or a provider fails,
    it returns a structured offline/unavailable result instead of fabricating news.
    """

    FINNHUB_URL = 'https://finnhub.io/api/v1'
    ALPHA_URL = 'https://www.alphavantage.co/query'

    def provider_status(self) -> dict[str, Any]:
        return {
            'finnhub_configured': bool(settings.finnhub_api_key),
            'alpha_vantage_configured': bool(settings.alpha_vantage_api_key),
            'internet_analysis_enabled': bool(settings.finnhub_api_key or settings.alpha_vantage_api_key),
            'preferred_provider': settings.internet_analysis_provider,
        }

    def analyze(self, symbol: str, query: str | None = None, max_items: int = 8) -> dict[str, Any]:
        symbol = symbol.strip().upper()
        articles: list[dict[str, Any]] = []
        provider_results: list[dict[str, Any]] = []

        if settings.internet_analysis_provider in {'auto', 'finnhub'} and settings.finnhub_api_key:
            result = self._finnhub_news(symbol, max_items=max_items)
            provider_results.append(result)
            articles.extend(result.get('articles', []))

        if settings.internet_analysis_provider in {'auto', 'alpha_vantage'} and settings.alpha_vantage_api_key and len(articles) < max_items:
            result = self._alpha_news_sentiment(symbol, query=query, max_items=max_items - len(articles))
            provider_results.append(result)
            articles.extend(result.get('articles', []))

        sentiment_score = self._aggregate_sentiment(articles)
        sentiment_label = self._sentiment_label(sentiment_score)
        risk_flags = self._risk_flags(articles)

        return {
            'symbol': symbol,
            'online': bool(articles),
            'provider_status': self.provider_status(),
            'providers': provider_results,
            'headline_count': len(articles),
            'sentiment_score': sentiment_score,
            'sentiment_label': sentiment_label,
            'risk_flags': risk_flags,
            'articles': articles[:max_items],
            'summary': self._build_summary(symbol, sentiment_label, articles, risk_flags),
            'generated_at': datetime.now(timezone.utc).isoformat(),
            'warning': None if articles else 'Keine Online-News/Sentiment-Daten geladen. API-Key fuer Finnhub oder Alpha Vantage setzen.',
        }

    def _finnhub_news(self, symbol: str, max_items: int) -> dict[str, Any]:
        try:
            response = requests.get(
                f'{self.FINNHUB_URL}/company-news',
                params={
                    'symbol': symbol,
                    'from': datetime.now(timezone.utc).date().replace(day=1).isoformat(),
                    'to': datetime.now(timezone.utc).date().isoformat(),
                    'token': settings.finnhub_api_key,
                },
                timeout=12,
            )
            response.raise_for_status()
            data = response.json()
            articles = []
            for item in data[:max_items]:
                articles.append({
                    'source': item.get('source'),
                    'headline': item.get('headline'),
                    'summary': item.get('summary'),
                    'url': item.get('url'),
                    'datetime': item.get('datetime'),
                    'provider': 'finnhub',
                    'sentiment_score': None,
                })
            return {'provider': 'finnhub', 'status': 'online', 'articles': articles}
        except Exception as exc:
            return {'provider': 'finnhub', 'status': 'error', 'error': str(exc), 'articles': []}

    def _alpha_news_sentiment(self, symbol: str, query: str | None, max_items: int) -> dict[str, Any]:
        try:
            response = requests.get(
                self.ALPHA_URL,
                params={
                    'function': 'NEWS_SENTIMENT',
                    'tickers': symbol,
                    'topics': query or '',
                    'apikey': settings.alpha_vantage_api_key,
                    'limit': max_items,
                },
                timeout=12,
            )
            response.raise_for_status()
            data = response.json()
            feed = data.get('feed') or []
            articles = []
            for item in feed[:max_items]:
                score = self._safe_float(item.get('overall_sentiment_score'))
                articles.append({
                    'source': item.get('source'),
                    'headline': item.get('title'),
                    'summary': item.get('summary'),
                    'url': item.get('url'),
                    'datetime': item.get('time_published'),
                    'provider': 'alpha_vantage',
                    'sentiment_score': score,
                    'sentiment_label': item.get('overall_sentiment_label'),
                })
            return {'provider': 'alpha_vantage', 'status': 'online', 'articles': articles}
        except Exception as exc:
            return {'provider': 'alpha_vantage', 'status': 'error', 'error': str(exc), 'articles': []}

    def _aggregate_sentiment(self, articles: list[dict[str, Any]]) -> float:
        scores = [float(a['sentiment_score']) for a in articles if a.get('sentiment_score') is not None]
        if not scores:
            return 0.0
        return round(sum(scores) / len(scores), 4)

    def _sentiment_label(self, score: float) -> str:
        if score >= 0.25:
            return 'positiv'
        if score <= -0.25:
            return 'negativ'
        return 'neutral/unbekannt'

    def _risk_flags(self, articles: list[dict[str, Any]]) -> list[str]:
        keywords = {
            'earnings': 'Earnings/Quartalszahlen im Nachrichtenkontext',
            'lawsuit': 'Rechts-/Klage-Risiko im Nachrichtenkontext',
            'investigation': 'Untersuchungs-/Regulierungsrisiko im Nachrichtenkontext',
            'sec': 'SEC-/Regulierungsbezug im Nachrichtenkontext',
            'downgrade': 'Analysten-Downgrade im Nachrichtenkontext',
            'bankruptcy': 'Insolvenz-/Finanzierungsrisiko im Nachrichtenkontext',
        }
        text = ' '.join([str(a.get('headline') or '') + ' ' + str(a.get('summary') or '') for a in articles]).lower()
        return [label for keyword, label in keywords.items() if keyword in text]

    def _build_summary(self, symbol: str, sentiment_label: str, articles: list[dict[str, Any]], risk_flags: list[str]) -> str:
        if not articles:
            return f'Keine Online-Analyse fuer {symbol} verfuegbar. Entscheidung basiert nur auf Kursdaten, Indikatoren und Risiko-Regeln.'
        flag_text = ' Risiko-Hinweise: ' + '; '.join(risk_flags) if risk_flags else ''
        return f'Online-Kontext fuer {symbol}: {len(articles)} News/Sentiment-Treffer, aggregiertes Sentiment: {sentiment_label}.{flag_text}'

    def _safe_float(self, value: Any) -> float | None:
        try:
            if value is None:
                return None
            return float(value)
        except Exception:
            return None


internet_analysis_service = InternetAnalysisService()
