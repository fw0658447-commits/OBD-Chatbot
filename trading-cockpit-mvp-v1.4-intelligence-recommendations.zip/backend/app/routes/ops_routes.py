from __future__ import annotations

from app.config import settings
from fastapi import APIRouter

from app.repositories.trading_repository import trading_repository
from app.services.market_cache_service import market_cache_service
from app.services.validation_monitoring_service import validation_monitoring_service
from app.services.identifier_service import identifier_service
from app.services.internet_analysis_service import internet_analysis_service

router = APIRouter()


@router.get('/readiness')
def readiness():
    snapshot = trading_repository.ops_readiness_snapshot()
    checks = {
        'live_trading_hard_locked': settings.live_trading_hard_locked and not settings.live_trading_enabled,
        'paper_cost_model_enabled': settings.paper_spread_bps > 0 or settings.paper_slippage_bps > 0 or settings.paper_commission_bps > 0,
        'cache': market_cache_service.status(),
        'market_provider': settings.market_data_provider,
        'fallback_enabled': settings.market_provider_fallback_enabled,
        'block_trades_on_data_quality_fail': settings.block_trades_on_data_quality_fail,
    }
    blocking = list(snapshot.get('blocking_reasons') or [])
    if not checks['live_trading_hard_locked']:
        blocking.append('Live trading hard lock is not active.')
    if not checks['paper_cost_model_enabled']:
        blocking.append('Paper cost model is disabled; results are too optimistic.')
    validation = validation_monitoring_service.validation_gates()
    if not validation.get('released_for_paper_automation'):
        blocking.append('Validation gates are not fully released for production-like paper automation.')
    ready = not blocking and bool(snapshot.get('persistence_reachable'))
    return {
        'status': 'ready' if ready else 'not_ready',
        'ready_for_realistic_paper_trading': ready,
        'blocking_reasons': blocking,
        'warnings': snapshot.get('warnings', []),
        'repository': snapshot,
        'checks': checks,
        'validation': validation,
        'recommended_next_gate': 'Pass v1.2 validation gates: >=100 closed paper trades, adequate Profit Factor, controlled Drawdown and clean data-quality reports.',
    }


@router.get('/status')
def system_status():
    """Operational status for the UI: online/offline, data provider, cache, DB and trading locks."""
    provider = settings.market_data_provider
    has_api_key = bool(settings.market_data_api_key)
    cache_status = market_cache_service.status()
    database_reachable = trading_repository.available if trading_repository.enabled else False
    market_check = {
        'status': 'unknown',
        'symbol': 'BTC/USD',
        'provider': provider,
        'price': None,
        'error': None,
        'fallback_used': False,
    }
    try:
        from app.services.market_data_service import get_market_data_service
        quote = get_market_data_service().get_quote('BTC/USD')
        market_check.update({
            'status': 'online' if not quote.get('error') else 'error',
            'provider': quote.get('provider', provider),
            'price': quote.get('price'),
            'timestamp': quote.get('timestamp'),
            'cache': quote.get('cache'),
            'fallback_used': bool(quote.get('fallback_reason')),
            'fallback_reason': quote.get('fallback_reason'),
        })
    except Exception as exc:
        market_check.update({'status': 'offline', 'error': str(exc)})

    real_provider_configured = provider != 'mock' and has_api_key
    simulated_data = provider == 'mock' or market_check.get('provider') == 'mock'
    return {
        'status': 'online' if database_reachable and market_check['status'] in {'online', 'error'} else 'degraded',
        'backend': 'online',
        'database': 'online' if database_reachable else 'offline',
        'cache': cache_status,
        'market_data': market_check,
        'market_data_provider': provider,
        'real_provider_configured': real_provider_configured,
        'simulated_data': simulated_data,
        'fallback_enabled': settings.market_provider_fallback_enabled,
        'live_trading_enabled': settings.live_trading_enabled,
        'live_trading_hard_locked': settings.live_trading_hard_locked,
        'paper_mode': settings.bot_mode == 'paper',
        'identifier_provider': identifier_service.provider_status(),
        'internet_analysis_provider': internet_analysis_service.provider_status(),
        'recommended_action': 'API-Key fuer echte Marktdaten setzen.' if not real_provider_configured else 'Datenqualitaet pruefen und Paper-Trading fortsetzen.',
    }
