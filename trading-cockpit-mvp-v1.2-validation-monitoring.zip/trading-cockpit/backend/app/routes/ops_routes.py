from __future__ import annotations

from app.config import settings
from fastapi import APIRouter

from app.repositories.trading_repository import trading_repository
from app.services.market_cache_service import market_cache_service
from app.services.validation_monitoring_service import validation_monitoring_service

router = APIRouter()


@router.get('/readiness')
def readiness():
    snapshot = trading_repository.ops_readiness_snapshot()
    checks = {
        'live_trading_hard_locked': settings.live_trading_hard_locked and not settings.live_trading_enabled,
        'paper_cost_model_enabled': settings.paper_spread_bps > 0 or settings.paper_slippage_bps > 0 or settings.paper_commission_bps > 0,
        'cache': market_cache_service.status(),
        'market_provider': settings.market_data_provider,
        'fallback_enabled': settings.market_provider_fallback_enabled,
        'block_trades_on_data_quality_fail': settings.block_trades_on_data_quality_fail,
    }
    blocking = list(snapshot.get('blocking_reasons') or [])
    if not checks['live_trading_hard_locked']:
        blocking.append('Live trading hard lock is not active.')
    if not checks['paper_cost_model_enabled']:
        blocking.append('Paper cost model is disabled; results are too optimistic.')
    validation = validation_monitoring_service.validation_gates()
    if not validation.get('released_for_paper_automation'):
        blocking.append('Validation gates are not fully released for production-like paper automation.')
    ready = not blocking and bool(snapshot.get('persistence_reachable'))
    return {
        'status': 'ready' if ready else 'not_ready',
        'ready_for_realistic_paper_trading': ready,
        'blocking_reasons': blocking,
        'warnings': snapshot.get('warnings', []),
        'repository': snapshot,
        'checks': checks,
        'validation': validation,
        'recommended_next_gate': 'Pass v1.2 validation gates: >=100 closed paper trades, adequate Profit Factor, controlled Drawdown and clean data-quality reports.',
    }
