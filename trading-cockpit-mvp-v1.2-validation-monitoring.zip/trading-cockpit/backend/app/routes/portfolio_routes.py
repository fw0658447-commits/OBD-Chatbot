from fastapi import APIRouter

from app.repositories.trading_repository import trading_repository
from app.services.bot_engine import BotEngine

router = APIRouter()


@router.get('/paper')
def get_paper_portfolio():
    if not trading_repository.available:
        return {
            'cash_balance': 10000.0,
            'starting_balance': 10000.0,
            'current_equity': 10000.0,
            'total_realized_pnl': 0.0,
            'total_unrealized_pnl': 0.0,
            'positions': [],
            'note': 'DATABASE_URL ist nicht gesetzt. Das Backend nutzt lokale Platzhalterdaten.',
        }
    snapshot = BotEngine().portfolio_snapshot()
    return snapshot.get('portfolio')


@router.get('/paper/orders')
def get_paper_orders(status: str | None = None):
    if not trading_repository.available:
        return {'items': [], 'persistence': 'memory'}
    return {'items': trading_repository.list_paper_orders(status=status, limit=200), 'persistence': 'postgres'}


@router.get('/paper/performance')
def get_paper_performance():
    if not trading_repository.available:
        return {
            'persistence': 'memory',
            'total_orders': 0,
            'closed_orders': 0,
            'open_orders': 0,
        }
    return trading_repository.performance_summary()
