from __future__ import annotations

import math
import random
from datetime import datetime, timedelta, timezone
from typing import Dict, List

import requests

from app.config import settings
from app.services.market_cache_service import market_cache_service


class MarketDataError(RuntimeError):
    pass


class MockMarketDataService:
    """Deterministic-enough mock data for local MVP development.

    This lets the bot, indicators and frontend be tested without a paid API key.
    """

    def search_assets(self, query: str) -> List[Dict]:
        universe = [
            {'symbol': 'BTC/USD', 'name': 'Bitcoin US Dollar', 'asset_type': 'crypto'},
            {'symbol': 'ETH/USD', 'name': 'Ethereum US Dollar', 'asset_type': 'crypto'},
            {'symbol': 'AAPL', 'name': 'Apple Inc.', 'asset_type': 'stock'},
            {'symbol': 'MSFT', 'name': 'Microsoft Corp.', 'asset_type': 'stock'},
            {'symbol': 'SPY', 'name': 'SPDR S&P 500 ETF', 'asset_type': 'etf'},
            {'symbol': 'EUR/USD', 'name': 'Euro US Dollar', 'asset_type': 'forex'},
            {'symbol': 'XAU/USD', 'name': 'Gold Spot US Dollar', 'asset_type': 'commodity'},
        ]
        q = query.lower().strip()
        return [item for item in universe if q in item['symbol'].lower() or q in item['name'].lower()]

    def get_quote(self, symbol: str) -> Dict:
        candles = self.get_candles(symbol=symbol, timeframe='1h', limit=5)
        last = candles[-1]
        previous = candles[-2]
        change = last['close'] - previous['close']
        change_percent = change / previous['close'] * 100
        return {
            'symbol': symbol,
            'price': round(last['close'], 4),
            'change': round(change, 4),
            'change_percent': round(change_percent, 2),
            'timestamp': last['timestamp'],
            'provider': 'mock',
        }

    def get_candles(self, symbol: str, timeframe: str, limit: int = 200) -> List[Dict]:
        base = self._base_price(symbol)
        interval_minutes = self._interval_minutes(timeframe)
        now = datetime.now(timezone.utc).replace(second=0, microsecond=0)
        start = now - timedelta(minutes=interval_minutes * (limit - 1))

        rng = random.Random(f'{symbol}-{timeframe}-{limit}')
        candles: List[Dict] = []
        close = base

        for i in range(limit):
            timestamp = start + timedelta(minutes=interval_minutes * i)
            trend = i * base * 0.00018
            wave = math.sin(i / 8) * base * 0.01
            noise = rng.uniform(-base * 0.003, base * 0.003)
            new_close = max(base * 0.1, base + trend + wave + noise)
            open_price = close
            high = max(open_price, new_close) * (1 + rng.uniform(0.0005, 0.004))
            low = min(open_price, new_close) * (1 - rng.uniform(0.0005, 0.004))
            volume = abs(rng.gauss(100000, 15000))

            candles.append({
                'timestamp': timestamp.isoformat(),
                'open': round(open_price, 4),
                'high': round(high, 4),
                'low': round(low, 4),
                'close': round(new_close, 4),
                'volume': round(volume, 2),
            })
            close = new_close

        return candles

    def _base_price(self, symbol: str) -> float:
        mapping = {
            'BTC/USD': 68000.0,
            'ETH/USD': 3600.0,
            'AAPL': 195.0,
            'MSFT': 430.0,
            'SPY': 525.0,
            'EUR/USD': 1.08,
            'XAU/USD': 2350.0,
        }
        return mapping.get(symbol.upper(), 100.0)

    def _interval_minutes(self, timeframe: str) -> int:
        mapping = {'1m': 1, '5m': 5, '15m': 15, '1h': 60, '4h': 240, '1d': 1440, '1D': 1440}
        return mapping.get(timeframe, 60)


class TwelveDataService:
    BASE_URL = 'https://api.twelvedata.com'

    def search_assets(self, query: str) -> List[Dict]:
        response = requests.get(
            f'{self.BASE_URL}/symbol_search',
            params={'symbol': query, 'apikey': settings.market_data_api_key},
            timeout=10,
        )
        response.raise_for_status()
        payload = response.json()
        items = payload.get('data', [])
        return [
            {
                'symbol': item.get('symbol'),
                'name': item.get('instrument_name') or item.get('symbol'),
                'asset_type': item.get('instrument_type'),
                'exchange': item.get('exchange'),
                'currency': item.get('currency'),
            }
            for item in items
        ]

    def get_quote(self, symbol: str) -> Dict:
        response = requests.get(
            f'{self.BASE_URL}/quote',
            params={'symbol': symbol, 'apikey': settings.market_data_api_key},
            timeout=10,
        )
        response.raise_for_status()
        data = response.json()
        if 'code' in data and data.get('status') == 'error':
            raise MarketDataError(data.get('message', 'Twelve Data error'))
        return {
            'symbol': symbol,
            'price': float(data.get('close') or data.get('price') or 0),
            'change': float(data.get('change') or 0),
            'change_percent': float(data.get('percent_change') or 0),
            'timestamp': data.get('datetime'),
            'provider': 'twelve_data',
        }

    def get_candles(self, symbol: str, timeframe: str, limit: int = 200) -> List[Dict]:
        response = requests.get(
            f'{self.BASE_URL}/time_series',
            params={
                'symbol': symbol,
                'interval': timeframe,
                'outputsize': limit,
                'apikey': settings.market_data_api_key,
            },
            timeout=10,
        )
        response.raise_for_status()
        data = response.json()
        if 'code' in data and data.get('status') == 'error':
            raise MarketDataError(data.get('message', 'Twelve Data error'))

        candles = []
        for row in data.get('values', []):
            candles.append({
                'timestamp': row['datetime'],
                'open': float(row['open']),
                'high': float(row['high']),
                'low': float(row['low']),
                'close': float(row['close']),
                'volume': float(row.get('volume') or 0),
            })
        return list(reversed(candles))



class CachedMarketDataService:
    def __init__(self, primary, fallback=None):
        self.primary = primary
        self.fallback = fallback

    def search_assets(self, query: str) -> List[Dict]:
        key = f'market:search:{query.lower().strip()}'
        cached = market_cache_service.get(key)
        if cached is not None:
            return cached
        try:
            result = self.primary.search_assets(query)
        except Exception:
            if self.fallback is None:
                raise
            result = self.fallback.search_assets(query)
        market_cache_service.set(key, result, ttl_seconds=300)
        return result

    def get_quote(self, symbol: str) -> Dict:
        key = f'market:quote:{symbol.upper()}'
        cached = market_cache_service.get(key)
        if cached is not None:
            cached['cache'] = 'hit'
            return cached
        try:
            result = self.primary.get_quote(symbol)
        except Exception as exc:
            if self.fallback is None:
                raise
            result = self.fallback.get_quote(symbol)
            result['fallback_reason'] = str(exc)
        result['cache'] = 'miss'
        market_cache_service.set(key, result, ttl_seconds=settings.quote_cache_ttl_seconds)
        return result

    def get_candles(self, symbol: str, timeframe: str, limit: int = 200) -> List[Dict]:
        key = f'market:candles:{symbol.upper()}:{timeframe}:{limit}'
        cached = market_cache_service.get(key)
        if cached is not None:
            return cached
        try:
            result = self.primary.get_candles(symbol, timeframe, limit)
        except Exception:
            if self.fallback is None:
                raise
            result = self.fallback.get_candles(symbol, timeframe, limit)
        market_cache_service.set(key, result, ttl_seconds=settings.candle_cache_ttl_seconds)
        return result


def get_market_data_service():
    if settings.market_data_provider == 'twelve_data' and settings.market_data_api_key:
        primary = TwelveDataService()
        fallback = MockMarketDataService() if settings.market_provider_fallback_enabled else None
        return CachedMarketDataService(primary=primary, fallback=fallback)
    return CachedMarketDataService(primary=MockMarketDataService())
