# Trading Cockpit MVP v1.0

KI-gestuetztes Trading-Cockpit mit Chart-Analyse, Watchlist, Paper-Trading-Bot, Risiko-Engine, Musterdepot-Grundlogik, PostgreSQL-Persistenz, automatischer Paper-Order-Auswertung und Backtesting.

## Status

Diese Version ist eine lauffaehige Paper-Trading-Version fuer MVP v1.0. Live-Trading bleibt bewusst deaktiviert.

Enthalten:

- FastAPI Backend
- Next.js Frontend mit interaktiver Analyse-Oberflaeche
- Candlestick-Chart mit TradingView Lightweight Charts
- Mock-Market-Data-Service fuer lokale Tests ohne API-Key
- optionale Twelve-Data-Anbindung per API-Key
- Marktueberblick fuer BTC/USD, ETH/USD, AAPL, MSFT, SPY, EUR/USD und XAU/USD
- Asset-Suche
- Watchlist mit Kursanreicherung
- technische Indikatoren: SMA, EMA, RSI, ATR, Trendstaerke, Volumenbestaetigung
- regelbasiertes KI-Scoring
- Long/Short/Neutral-Prognose mit Confidence Score und Risk Score
- Signal-Vorschau auf der Analyse-Seite
- Strategy Engine mit Strategie-Katalog fuer Trendfolge, Pullback, Breakout und Mean-Reversion
- Risk Engine mit harten Limits
- Paper-Trading-Engine
- PostgreSQL-Repository-Schicht mit Fallback auf lokalen Mock-/Memory-Modus
- persistente Speicherung von Prognosen, Signalen, Orders, Watchlist und Risikoereignissen
- automatische Auswertung offener Orders gegen aktuelle Kurse
- automatische Schliessung per Stop-Loss oder Take-Profit
- manuelles Schliessen von Paper-Orders per API
- mark-to-market Bewertung offener Positionen
- Portfolio-Kennzahlen: Equity, Realized P/L, Unrealized P/L
- Performance-Kennzahlen: Trefferquote, Profit Factor, Expectancy, Drawdown
- Bot Center im Frontend
- Backtesting-Modul fuer historische Strategiepruefung
- Equity-Kurve im Frontend
- Strategie-/Asset-Vergleich fuer mehrere Symbole, Timeframes und Strategietypen
- Walk-forward-/Out-of-sample-Teststruktur
- Speicherung von Backtest-Runs in PostgreSQL
- Parameter-Optimierung je Strategie mit Robust Score
- ML-Dataset-Export mit CSV-Ausgabe fuer spaeteres Modelltraining
- Speicherung von Optimierungslaeufen und Dataset-Exporten in PostgreSQL
- ML-Baseline-Training und Prognose-API
- Bot-Entscheidungsmodi: `rule`, `ml`, `ensemble`
- Ensemble-Gate aus Regelmodell + ML-Prognose
- Degradationserkennung fuer ML-Modelle
- Performance-Auswertung nach Entscheidungsmodus
- Live-Trading ist bewusst deaktiviert

- zentrale Bot-Konfiguration per API und Frontend
- Scheduler-Steuerung fuer Watchlist- und Symbol-Listen
- Scheduler-Run-Historie
- persistente Decision-Audits fuer erlaubte, blockierte und fehlende Signale
- konfigurierbare Risk Limits ohne Codeaenderung
- Kill-Switch-Zustand mit Reset-Endpunkt
- Equity-Kurve aus geschlossenen Paper-Orders

## Schnellstart mit Docker

```bash
docker compose up --build
```

API:

```text
http://localhost:8000/docs
```

Frontend:

```text
http://localhost:3000
```

## Schnellstart lokal ohne Docker

Backend:

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Frontend:

```bash
cd frontend
npm install
npm run dev
```

Dann im Browser:

```text
http://localhost:3000
```

## Echte Marktdaten aktivieren

Standardmaessig laeuft das Projekt mit Mock-Daten. Fuer Twelve Data:

```bash
export MARKET_DATA_PROVIDER=twelve_data
export MARKET_DATA_API_KEY=DEIN_API_KEY
```

Oder in `docker-compose.yml` fuer Backend und Worker setzen:

```yaml
MARKET_DATA_PROVIDER: twelve_data
MARKET_DATA_API_KEY: dein_api_key
```



## Neue Funktionen v1.0

- zentrale Bot-Konfiguration: `GET/PATCH /api/bot/config`
- Bot aktivieren/deaktivieren: `POST /api/bot/enable`, `POST /api/bot/disable`
- In-App-Scheduler fuer Paper-Bot-Zyklen:
  - `GET /api/bot/scheduler/status`
  - `POST /api/bot/scheduler/start`
  - `POST /api/bot/scheduler/stop`
  - `POST /api/bot/scheduler/run-once`
  - `GET /api/bot/scheduler/runs`
- persistente Decision-Audits: `GET /api/bot/decision-audits`
- Equity-Kurve aus Paper-Orders: `GET /api/bot/equity-curve`
- Kill-Switch Reset: `POST /api/bot/kill-switch/reset`
- neue Datenbankmigration: `database/migrations/0007_v10_paper_trading_ops.sql`
- neue Dokumentation: `docs/paper_trading_v10.md`

## Neue Funktionen v0.9

- Bot-Cycle akzeptiert `decision_mode`: `rule`, `ml` oder `ensemble`
- `model_id` kann optional angegeben werden; leer bedeutet neuestes lokales Modell
- ML-Prognose kann Signale blockieren, wenn Richtung oder Wahrscheinlichkeit nicht passen
- Ensemble-Modus verlangt Uebereinstimmung von Regelmodell und ML-Modell
- optionaler Rule-Fallback, wenn das ML-Modell nicht verfuegbar oder degradiert ist
- neue API-Endpunkte:
  - `GET /api/bot/model-health`
  - `GET /api/bot/performance-by-mode`
- neue Datenbankmigration: `database/migrations/0006_bot_decision_modes.sql`
- neue Dokumentation: `docs/ensemble_bot_v09.md`

## Neue Funktionen v0.8

- Strategie-Katalog im Backend
- vier Strategien: `trend_atr_v0.8`, `pullback_ema_v0.8`, `breakout_range_v0.8`, `mean_reversion_rsi_v0.8`
- `GET /api/backtest/strategies` fuer Strategie-Metadaten
- `POST /api/backtest/run` akzeptiert jetzt `strategy_name`
- `POST /api/backtest/compare` vergleicht Assets, Timeframes und Strategien
- `POST /api/backtest/walk-forward` fuer erste Out-of-sample-Stabilitaetspruefung
- Analyse-Frontend mit Strategieauswahl
- Backtesting-Frontend mit Strategie-Katalog, Vergleich und Walk-forward-Ergebnis
- Datenbankmigration `database/migrations/0003_strategy_catalog.sql` fuer Strategie-Indizes

## API-Endpunkte

Market:

```text
GET  /api/market/overview
GET  /api/market/assets/search?q=btc
GET  /api/market/quote?symbol=BTC/USD
GET  /api/market/candles?symbol=BTC/USD&timeframe=1h
GET  /api/market/indicators?symbol=BTC/USD&timeframe=1h
GET  /api/market/analysis?symbol=BTC/USD&timeframe=1h&strategy_name=trend_atr_v0.8&limit=220
```

Backtest:

```text
GET  /api/backtest/strategies
POST /api/backtest/run
POST /api/backtest/compare
POST /api/backtest/walk-forward
GET  /api/backtest/runs
```

Bot:

```text
GET  /api/bot/persistence
GET  /api/bot/config
PATCH /api/bot/config
POST /api/bot/enable
POST /api/bot/disable
GET  /api/bot/scheduler/status
POST /api/bot/scheduler/start
POST /api/bot/scheduler/stop
POST /api/bot/scheduler/run-once
GET  /api/bot/scheduler/runs
GET  /api/bot/decision-audits
GET  /api/bot/equity-curve
GET  /api/bot/predictions
GET  /api/bot/signals
GET  /api/bot/orders
GET  /api/bot/risk-events
GET  /api/bot/portfolio-snapshot
GET  /api/bot/performance
POST /api/bot/run-cycle
POST /api/bot/evaluate-open-orders
POST /api/bot/close-order/{order_id}
POST /api/bot/kill-switch
```

Watchlist:

```text
GET    /api/watchlist
POST   /api/watchlist
DELETE /api/watchlist/{symbol}
```

Portfolio:

```text
GET  /api/portfolio/paper
GET  /api/portfolio/paper/orders
GET  /api/portfolio/paper/performance
```

## Erste Tests per curl

Analyse abrufen:

```bash
curl 'http://localhost:8000/api/market/analysis?symbol=BTC/USD&timeframe=1h&strategy_name=trend_atr_v0.8&limit=220'
```

Backtest starten:

```bash
curl -X POST http://localhost:8000/api/backtest/run \
  -H 'Content-Type: application/json' \
  -d '{"symbol":"BTC/USD","timeframe":"1h","strategy_name":"trend_atr_v0.8","limit":420,"initial_capital":10000,"persist":true}'
```

Backtest-Vergleich:

```bash
curl -X POST http://localhost:8000/api/backtest/compare \
  -H 'Content-Type: application/json' \
  -d '{"symbols":["BTC/USD","ETH/USD","AAPL","SPY"],"timeframes":["1h","4h"],"strategies":["trend_atr_v0.8","pullback_ema_v0.8","breakout_range_v0.8","mean_reversion_rsi_v0.8"],"limit":420,"initial_capital":10000}'
```

Bot Status:

```bash
curl http://localhost:8000/api/bot/status
```

Bot Cycle mit Mock-Daten:

```bash
curl -X POST http://localhost:8000/api/bot/run-cycle \
  -H 'Content-Type: application/json' \
  -d '{"symbol":"BTC/USD","timeframe":"1h","portfolio_value":10000,"open_trades_count":0,"daily_pnl_percent":0,"strategy_name":"trend_atr_v0.8"}'
```

Offene Paper-Orders auswerten:

```bash
curl -X POST http://localhost:8000/api/bot/evaluate-open-orders
```

Portfolio-Snapshot abrufen:

```bash
curl http://localhost:8000/api/bot/portfolio-snapshot
```

## Upgrade von v0.5 auf v0.8 bei bestehender Datenbank

Wenn du einen bestehenden PostgreSQL-Container aus v0.4 weiterverwendest, fuehre die Migration aus:

```bash
psql "$DATABASE_URL" -f database/migrations/0003_strategy_catalog.sql
```

Bei frischer Docker-Installation ist die Tabelle bereits in `database/init.sql` enthalten.

## Sicherheitsmodell

Live-Trading ist in dieser Version bewusst deaktiviert. Der Bot ist Paper-only.

Standardlimits:

- Risiko pro Trade: 1 Prozent
- Maximaler Tagesverlust: 2 Prozent
- Maximal offene Trades: 3
- Mindest-CRV: 2.0
- Mindest-Confidence: 65
- Maximaler Risk Score: 70

## Naechste Schritte

1. ML-Trainingsdatensatz aus Prognosen, Backtests und Paper-Trades erzeugen
2. Parameter-Sweeps je Strategie einbauen
3. Walk-forward-Auswertung mit Trainings-/Validierungsfenstern erweitern
4. News-/Sentiment-Modul ergaenzen
5. erst danach Semi-Auto-Broker-Anbindung vorbereiten


## v0.8 Baseline-ML

Neu in v0.8:

- erste ML-Trainingspipeline
- Random-Forest- und Logistic-Regression-Baseline
- chronologischer Holdout-Test
- Vergleich Regelmodell vs. ML-Modell
- Modellversionen in `/tmp/trading-cockpit-models`
- PostgreSQL-Registry fuer Modellmetadaten
- Asset-Prognose ueber trainiertes Modell

Beispieltraining:

```bash
curl -X POST http://localhost:8000/api/ml/train \
  -H 'Content-Type: application/json' \
  -d '{"symbols":["BTC/USD","ETH/USD","AAPL","SPY"],"timeframes":["1h"],"strategies":["trend_atr_v0.7","pullback_ema_v0.7"],"limit":650,"lookahead_bars":12,"max_rows":3000,"model_type":"random_forest","persist":true}'
```

Asset-Prognose nach dem Training:

```bash
curl -X POST http://localhost:8000/api/ml/predict-asset \
  -H 'Content-Type: application/json' \
  -d '{"symbol":"BTC/USD","timeframe":"1h","strategy_name":"trend_atr_v0.7"}'
```


## Neu in v0.9

- Bot-Entscheidungsmodi: `rule`, `ml`, `ensemble`
- ML-Modell als Filter fuer Paper-Bot-Signale
- Ensemble-Entscheidung aus Regelmodell + ML-Prognose
- Degradationserkennung fuer ML-Modelle
- automatischer Rule-Fallback im Ensemble-Modus, wenn aktiviert
- Performance-Auswertung nach Entscheidungsmodus
- neue Endpunkte: `/api/bot/model-health`, `/api/bot/performance-by-mode`
- Live-Trading bleibt weiterhin deaktiviert

Siehe `docs/ensemble_bot_v09.md`.


Bot-Konfiguration anzeigen:

```bash
curl http://localhost:8000/api/bot/config
```

Bot-Konfiguration anpassen:

```bash
curl -X PATCH http://localhost:8000/api/bot/config \
  -H 'Content-Type: application/json' \
  -d '{"bot_enabled":true,"symbols":["BTC/USD","ETH/USD"],"timeframes":["1h"],"decision_mode":"rule","max_risk_per_trade":0.01,"max_open_trades":3}'
```

Scheduler einmal ausfuehren:

```bash
curl -X POST http://localhost:8000/api/bot/scheduler/run-once
```

Decision-Audits anzeigen:

```bash
curl http://localhost:8000/api/bot/decision-audits
```

Equity-Kurve anzeigen:

```bash
curl http://localhost:8000/api/bot/equity-curve
```


## v1.2 Real-Market-Readiness

Diese Version erweitert v1.0 um reale Betriebsfunktionen fuer sinnvolles Paper-Trading:

- Datenqualitaets-Gate vor jedem Bot-Trade
- Kerzenpersistenz in PostgreSQL
- Redis-/Memory-Cache fuer Quotes und Candles
- Twelve-Data-Fallback auf Mock-Daten
- realistischere Paper-Fills mit Spread, Slippage und Kommission
- CSV-Export fuer Orders, Signale, Prognosen, Decision-Audits, Backtests und Datenqualitaetsreports
- Operations-Readiness-Endpunkt unter `/api/ops/readiness`

Wichtig: Live-Trading ist weiterhin hart gesperrt. Die Version ist fuer realistischeres Paper-Trading und Strategievalidierung gedacht.


## v1.2 Validation & Monitoring

Neue Endpunkte fuer den realistischeren Paper-Betrieb:

```bash
curl http://localhost:8000/api/monitoring/validation-gates
curl http://localhost:8000/api/monitoring/daily-report
curl http://localhost:8000/api/monitoring/alerts
curl http://localhost:8000/api/monitoring/system-report
```

Optional kann die Freigabe-Sperre aktiviert werden:

```bash
curl -X PATCH http://localhost:8000/api/bot/config \
  -H 'Content-Type: application/json' \
  -d '{"enforce_validation_gate":true,"min_closed_trades_for_release":100,"min_profit_factor_for_release":1.15}'
```

Dann blockiert der Paper-Bot neue Orders, solange die Validierungs-Gates nicht bestanden sind.
